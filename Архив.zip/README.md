# Delivery manager
Save your delivery and order numbers in online shops.\n
On right click you're able to add new order number. This may help you to manage 
multiple shops orders. When you have more than two coming orders it is difficult 
to keep in mind which number you should say on call or whatever.\n
Also you may need to check delivery status. With this plugin you don't need to remember
shop address.
Plugin has menu where you can check delivered orders and they will dissapear.

Demo video - https://www.youtube.com/watch?v=0MRGz0TD_oA